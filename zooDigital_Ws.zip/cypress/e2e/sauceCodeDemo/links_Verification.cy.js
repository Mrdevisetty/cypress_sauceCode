/// <reference types="cypress" />
require('cypress-xpath');
                   


describe('sauce Demo UI actions', () => {

  beforeEach(() => {
    cy.visit('https://www.saucedemo.com')
  })


  it('Verify the page', () => {

    cy.intercept('POST', '*', { times: 1 })  // 'POST, '*' means any URL
  .as('post') 

    cy.visit('www.saucedemo.com')
    cy.get('[data-test="username"]').type('standard_user')
    cy.get('[data-test="password"]').type('secret_sauce')
    cy.get('[data-test="login-button"]').click();
    cy.url().should('satisfy', (url) => url.includes('/inventory.html'));


    //work in progress
    cy.xpath('//footer[@class="footer"]//li').should('have.length', 3)

    for(let i=1;i<=3;i++){

      cy.xpath('//footer[@class="footer"]//li['+i+']/a').click()            
      cy.wait('@post')          // wait for intercept 
      .then(interception => {
        // read the response
        expect(interception.response.status).to.eq(200)
      })


    }

    // cy.request('https://jsonplaceholder.typicode.com/comments').then((response) => {
    //   expect(response.status).to.eq(200)
    //   expect(response.body).to.have.length(500)
    //   expect(response).to.have.property('headers')
    //   expect(response).to.have.property('duration')
    // })






  })

  
})
